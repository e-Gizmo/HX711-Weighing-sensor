# YHX711
This is an Arduino library for hx711 ADC chip for weighing scales.
https://cdn.sparkfun.com/datasheets/Sensors/ForceFlex/hx711_english.pdf

This is a stripped version of this library:https://github.com/aguegu/ardulibs/tree/master/hx711
with added setMode() function for selecting input channel and gain

setmode(1) to read Channel A with Gain of 128

setmode(2) to read Channel B with Gain of 32

setmode(3) to read Channel A with Gain of 64
